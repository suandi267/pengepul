<?php
// Hanya mulai sesi jika belum ada sesi yang aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Aktifkan pelaporan kesalahan untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Sertakan file koneksi database
require_once __DIR__ . '/../config/database.php';

// Judul halaman default jika tidak diatur
if (!isset($page_title)) {
    $page_title = 'Admin Panel';
}

// Define the base path dynamically to support running in a subfolder.
$project_root = str_replace('\\', '/', dirname(__DIR__));
$doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_path = str_replace($doc_root, '', $project_root) . '/';

// Ambil jumlah notifikasi yang belum dibaca untuk admin
$unread_count = 0; // Inisialisasi
if (isset($_SESSION['user_id']) && isset($connection)) {
    try {
        $admin_id = $_SESSION['user_id'];
        $notif_sql = "SELECT COUNT(id) as unread_count FROM notifications WHERE user_id = ? AND is_read = 0";
        
        // Gunakan prepared statement untuk keamanan
        $stmt_notif = $connection->prepare($notif_sql);
        if ($stmt_notif) {
            $stmt_notif->bind_param('i', $admin_id);
            $stmt_notif->execute();
            $notif_result = $stmt_notif->get_result();
            $data = $notif_result->fetch_assoc();
            if ($data) {
                $unread_count = $data['unread_count'];
            }
            $stmt_notif->close();
        }
    } catch (mysqli_sql_exception $e) {
        // Jika terjadi error, biarkan unread_count = 0 dan jangan hentikan script
        // Opsional: bisa ditambahkan logging error di sini
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($page_title); ?></title>
    
    <!-- Bootstrap CSS (Bootswatch Cosmo) -->
    <link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.2/dist/cosmo/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome untuk Ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- CSS Admin Kustom -->
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/admin_style.css">

    <!-- Chart.js untuk Grafik -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo $base_path; ?>admin/index.php">Admin Panel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/manage_agents.php"><i class="fas fa-users-cog"></i> Kelola Agen</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/manage_items.php"><i class="fas fa-box"></i> Kelola Barang</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/manage_prices.php"><i class="fas fa-dollar-sign"></i> Kelola Harga</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/laporan_transaksi.php"><i class="fas fa-file-alt"></i> Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $base_path; ?>admin/rekap_pendapatan.php"><i class="fas fa-chart-line"></i> Rekap Pendapatan</a></li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $base_path; ?>admin/notifikasi.php">
                        <i class="fas fa-bell"></i> Notifikasi 
                        <?php if($unread_count > 0): ?>
                            <span class="badge bg-danger rounded-pill"><?php echo $unread_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user"></i> <?php echo isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : 'Admin'; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo $base_path; ?>logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="container-fluid my-4">
</div> <!-- Closing the .container mt-4 from header.php -->

<footer class="bg-dark text-white mt-5 pt-5 pb-4">
    <div class="container text-center text-md-start">
        <div class="row">
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold text-primary">Kepul Point</h6>
                <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #007bff; height: 2px"/>
                <p>
                    Sistem manajemen sampah berbasis poin untuk membantu proses daur ulang menjadi lebih efisien dan menguntungkan bagi semua pihak.
                </p>
            </div>

            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold">Layanan</h6>
                <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #007bff; height: 2px"/>
                <p><a href="<?php echo $base_path; ?>request_pickup.php" class="text-white-50">Jemput Sampah</a></p>
                <p><a href="<?php echo $base_path; ?>index.php#pricelist" class="text-white-50">Daftar Harga</a></p>
            </div>

            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold">Tautan</h6>
                <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #007bff; height: 2px"/>
                <p><a href="<?php echo $base_path; ?>register.php" class="text-white-50">Daftar</a></p>
                <p><a href="<?php echo $base_path; ?>login.php" class="text-white-50">Login</a></p>
                <p><a href="#" class="text-white-50">Bantuan</a></p>
            </div>

            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                <h6 class="text-uppercase fw-bold">Kontak</h6>
                <hr class="mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; background-color: #007bff; height: 2px"/>
                <p><i class="bi bi-geo-alt-fill me-3"></i> Hkbp Merek tanah karo, Indonesia</p>
                <p><i class="bi bi-envelope-fill me-3"></i> info@kepulpoint.com</p>
                <p><i class="bi bi-telephone-fill me-3"></i> +62 21 1234 5678</p>
                 <p><i class="bi bi-developer-fill me-3"></i> Developer Suandi Simanjorang</p>
            </div>
        </div>
        
        <div class="d-flex justify-content-center justify-content-lg-between p-4 border-top border-secondary">
            <div class="me-5 d-none d-lg-block">
                <span>Terhubung dengan kami di media sosial:</span>
            </div>
            <div>
                <a href="#" class="me-4 text-reset"><i class="bi bi-facebook"></i></a>
                <a href="#" class="me-4 text-reset"><i class="bi bi-twitter"></i></a>
                <a href="#" class="me-4 text-reset"><i class="bi bi-instagram"></i></a>
                <a href="#" class="me-4 text-reset"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>
    </div>

    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © <?php echo date('Y'); ?> Copyright:
        <a class="text-white" href="<?php echo $base_path; ?>index.php">KepulPoint.com</a>
    </div>
</footer>

<!-- Leaflet.js JavaScript -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<!-- Bootstrap JS Bundle (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
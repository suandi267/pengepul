</main>

<footer class="footer mt-auto py-4 bg-dark text-white">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-6 text-md-start">
                <small>&copy; <?php echo date('Y'); ?> Kepul Point - All Rights Reserved</small>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                <a href="#" class="text-white"><i class="bi bi-instagram"></i></a>
            </div>
        </div>
    </div>
</footer>

<!-- Leaflet.js JavaScript -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>

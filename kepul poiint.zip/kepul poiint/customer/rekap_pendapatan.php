<?php
session_start();
include_once '../config/database.php';

// Pastikan hanya customer yang bisa mengakses halaman ini
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$page_title = "Rekap Pendapatan Anda";
include_once '../templates/header.php';

$transactions = [];
$error_message = '';
$customer_id = $_SESSION['user_id'];

try {
    // Ambil semua data transaksi untuk customer yang sedang login
    $stmt_transactions = $connection->prepare("SELECT t.id, u.name as agent_name, wt.name as waste_type, t.weight_kg, t.total_price, t.transaction_date 
                                             FROM transactions t
                                             JOIN users u ON t.agent_id = u.id
                                             JOIN waste_types wt ON t.waste_type_id = wt.id
                                             WHERE t.customer_id = ? AND t.status = 'selesai'
                                             ORDER BY t.transaction_date DESC");
    $stmt_transactions->bind_param('i', $customer_id);
    $stmt_transactions->execute();
    $result_transactions = $stmt_transactions->get_result();
    $transactions = $result_transactions->fetch_all(MYSQLI_ASSOC);
    $stmt_transactions->close();

} catch (mysqli_sql_exception $e) {
    $error_message = "Gagal memuat data rekap pendapatan: " . $e->getMessage();
}

?>

<div class="container-fluid">
    <h1 class="my-4">Rekap Pendapatan Anda</h1>

    <?php if($error_message): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
    <?php else: ?>
        <h2 class="my-4">Detail Transaksi (Selesai)</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Nama Agen</th>
                        <th>Jenis Sampah</th>
                        <th>Berat (kg)</th>
                        <th>Total Harga</th>
                        <th>Tanggal Transaksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($transactions)): ?>
                        <?php foreach($transactions as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['agent_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['waste_type']); ?></td>
                                <td><?php echo number_format($row['weight_kg'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['total_price'], 2, ',', '.'); ?></td>
                                <td><?php echo date("d M Y, H:i", strtotime($row['transaction_date'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada data transaksi yang selesai.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php
include_once '../templates/footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
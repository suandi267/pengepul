<?php
session_start();

// Security check: Ensure user is a logged-in customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$customer_id = $_SESSION['user_id'];
$error_message = '';

try {
    // Mark a notification as read
    if (isset($_GET['action']) && $_GET['action'] === 'mark_read' && isset($_GET['id'])) {
        if (!isset($_GET['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_GET['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $notification_id = (int)$_GET['id'];
        $stmt = $connection->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param('ii', $notification_id, $customer_id);
        $stmt->execute();
        $stmt->close();

        // --- Secure Redirect Logic ---
        $redirect_link = 'notifikasi.php'; // Default redirect
        if (isset($_GET['link'])) {
            $unsafe_link = $_GET['link'];
            // Whitelist of allowed pages for redirection
            $allowed_pages = ['index.php', 'request_pickup.php'];
            $parsed_url = parse_url($unsafe_link, PHP_URL_PATH);
            if (in_array(basename($parsed_url), $allowed_pages)) {
                $redirect_link = $unsafe_link;
            }
        }
        header("Location: " . $redirect_link);
        exit;
    }
} catch (Exception $e) {
    header("Location: notifikasi.php?error=" . urlencode("Terjadi kesalahan: " . $e->getMessage()));
    exit;
}

if(isset($_GET['error'])) $error_message = htmlspecialchars($_GET['error']);

$page_title = 'Notifikasi';
include '../templates/header.php';

$notifications = [];
$fetch_error = '';
try {
    $stmt = $connection->prepare("SELECT id, message, is_read, link, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->bind_param('i', $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (mysqli_sql_exception $e) {
    $fetch_error = "Gagal memuat notifikasi.";
}

?>

<main class="container my-5">
    <h2><?php echo htmlspecialchars($page_title); ?></h2>
    <p>Berikut adalah daftar notifikasi untuk Anda.</p>

    <?php if($error_message) echo '<div class="alert alert-danger">'.$error_message.'</div>'; ?>
    <?php if($fetch_error) echo '<div class="alert alert-danger">'.$fetch_error.'</div>'; ?>

    <div class="list-group">
        <?php if (!empty($notifications)): ?>
            <?php foreach($notifications as $row): ?>
                <a href="notifikasi.php?action=mark_read&id=<?php echo $row['id']; ?>&link=<?php echo urlencode($row['link']); ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
                   class="list-group-item list-group-item-action <?php echo $row['is_read'] ? 'list-group-item-light text-muted' : 'list-group-item-warning'; ?>">
                    <div class="d-flex w-100 justify-content-between">
                        <p class="mb-1"><?php echo htmlspecialchars($row['message']); ?></p>
                        <small class="text-nowrap"><?php echo date('d M Y, H:i', strtotime($row['created_at'])); ?></small>
                    </div>
                    <small><?php echo $row['is_read'] ? 'Sudah dibaca' : 'Klik untuk tandai sebagai sudah dibaca.'; ?></small>
                </a>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="list-group-item text-center">Tidak ada notifikasi baru.</div>
        <?php endif; ?>
    </div>
</main>

<?php
include '../templates/footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
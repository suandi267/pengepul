<?php
session_start();

// Security check: Ensure user is a logged-in customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error_message = '';
$success_message = '';

$customer_id = $_SESSION['user_id'];

// Initialize form fields
$customer_phone = '';
$customer_address = '';
$waste_description = '';

// Fetch customer data to pre-fill the form
try {
    $stmt = $connection->prepare("SELECT phone, address FROM users WHERE id = ?");
    $stmt->bind_param('i', $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($customer_data = $result->fetch_assoc()) {
        $customer_phone = $customer_data['phone'];
        $customer_address = $customer_data['address'];
    }
    $stmt->close();
} catch (Exception $e) {
    $error_message = "Gagal memuat data Anda.";
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 1. CSRF Check
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        // 2. Session User Validity Check
        $check_user_stmt = $connection->prepare("SELECT id FROM users WHERE id = ? AND role = 'customer'");
        $check_user_stmt->bind_param('i', $customer_id);
        $check_user_stmt->execute();
        $check_user_result = $check_user_stmt->get_result();
        if ($check_user_result->num_rows === 0) {
            session_unset();
            session_destroy();
            header("Location: ../login.php?error=" . urlencode("Sesi Anda tidak valid atau telah kedaluwarsa. Silakan login kembali."));
            exit;
        }
        $check_user_stmt->close();

        // 3. Form Input Processing and Validation
        $customer_name = $_SESSION['name'];
        $customer_phone = trim($_POST['customer_phone']);
        $customer_address = trim($_POST['customer_address']);
        $waste_description = trim($_POST['waste_description']);
        $latitude = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
        $longitude = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;

        if (empty($customer_phone) || empty($customer_address)) {
            throw new Exception("Nomor HP dan alamat harus diisi.");
        }
        if (!preg_match('/^(\+62|0)[0-9]{9,13}$/', $customer_phone)) {
            throw new Exception("Format nomor HP tidak valid. Gunakan format 08... atau +62...");
        }

        // 4. File Upload Handling
        $photo_filename = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/images/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $file_info = new finfo(FILEINFO_MIME_TYPE);
            $mime_type = $file_info->file($_FILES['photo']['tmp_name']);
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

            if (!in_array($mime_type, $allowed_types)) {
                throw new Exception("Format file tidak valid (JPG, PNG, GIF).");
            }
            if ($_FILES['photo']['size'] > 2000000) { // 2MB limit
                throw new Exception("Ukuran file maksimal 2MB.");
            }

            $file_extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $photo_filename = bin2hex(random_bytes(16)) . '.' . $file_extension;
            $target_file = $upload_dir . $photo_filename;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                throw new Exception("Gagal mengunggah file.");
            }
        }

        // 5. Database Insertion
        $connection->begin_transaction();

        $sql = "INSERT INTO pickup_requests (customer_id, customer_name, customer_phone, customer_address, waste_description, photo_url, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('isssssdd', $customer_id, $customer_name, $customer_phone, $customer_address, $waste_description, $photo_filename, $latitude, $longitude);
        $stmt->execute();
        $pickup_id = $connection->insert_id;
        $stmt->close();

        // 6. Notify Admins
        $message = "Permintaan jemput baru #{$pickup_id} dari {$customer_name}.";
        $link = "../admin/notifikasi.php?pickup_id={$pickup_id}";
        $notif_sql = "INSERT INTO notifications (user_id, message, link) SELECT id, ?, ? FROM users WHERE role = 'admin'";
        $notif_stmt = $connection->prepare($notif_sql);
        $notif_stmt->bind_param('ss', $message, $link);
        $notif_stmt->execute();
        $notif_stmt->close();

        $connection->commit();
        $success_message = "Permintaan jemput barang berhasil dikirim. Agen akan menghubungi Anda segera.";
        
        // Clear waste description for the next request
        $waste_description = '';

    } catch (Exception $e) {
        if (isset($connection) && $connection->in_transaction) $connection->rollback();
        $error_message = "Gagal mengirim permintaan: " . $e->getMessage();
    }
}

$page_title = 'Request Jemput Barang';
include '../templates/header.php';
?>

<main class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="text-center"><?php echo htmlspecialchars($page_title); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
                    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>

                    <form method="POST" action="request_pickup.php" enctype="multipart/form-data" id="pickup-form">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="latitude" id="latitude">
                        <input type="hidden" name="longitude" id="longitude">

                        <div class="mb-3">
                            <label for="customer_phone" class="form-label">Nomor HP</label>
                            <input type="tel" class="form-control" id="customer_phone" name="customer_phone" required value="<?php echo htmlspecialchars($customer_phone); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="customer_address" class="form-label">Alamat Lengkap</label>
                            <textarea class="form-control" id="customer_address" name="customer_address" rows="3" required><?php echo htmlspecialchars($customer_address); ?></textarea>
                            <div id="location-status" class="form-text mt-2"></div>
                            <button type="button" id="get-location-btn" class="btn btn-secondary btn-sm mt-2">Gunakan Lokasi Saya</button>
                        </div>

                        <div class="mb-3">
                            <label for="waste_description" class="form-label">Deskripsi Barang/Sampah</label>
                            <textarea class="form-control" id="waste_description" name="waste_description" rows="3"><?php echo htmlspecialchars($waste_description); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="photo" class="form-label">Foto Barang (Opsional, maks 2MB)</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/jpeg,image/png,image/gif">
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Kirim Permintaan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const getLocationBtn = document.getElementById('get-location-btn');
    const latitudeInput = document.getElementById('latitude');
    const longitudeInput = document.getElementById('longitude');
    const locationStatus = document.getElementById('location-status');

    if (getLocationBtn) {
        getLocationBtn.addEventListener('click', function() {
            if (!navigator.geolocation) {
                locationStatus.textContent = 'Geolocation tidak didukung oleh browser Anda.';
                locationStatus.className = 'form-text mt-2 text-danger';
            } else {
                locationStatus.textContent = 'Mendapatkan lokasi...';
                locationStatus.className = 'form-text mt-2 text-info';
                navigator.geolocation.getCurrentPosition(function(position) {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;

                    latitudeInput.value = latitude;
                    longitudeInput.value = longitude;

                    locationStatus.textContent = 'Lokasi berhasil didapatkan!';
                    locationStatus.className = 'form-text mt-2 text-success';
                }, function() {
                    locationStatus.textContent = 'Gagal mendapatkan lokasi. Pastikan Anda mengizinkan akses lokasi.';
                    locationStatus.className = 'form-text mt-2 text-danger';
                });
            }
        });
    }
});
</script>
<?php 
include '../templates/footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
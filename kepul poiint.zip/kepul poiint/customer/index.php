<?php
session_start();

// Security check: Ensure user is a logged-in customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$customer_id = $_SESSION['user_id'];
$error_message = '';
$success_message = '';

try {
    // Handle cancel action
    if (isset($_GET['action']) && $_GET['action'] === 'cancel' && isset($_GET['id'])) {
        if (!isset($_GET['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_GET['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $pickup_id = (int)$_GET['id'];

        // Update status to cancelled
        $sql = "UPDATE pickup_requests SET status = 'cancelled' WHERE id = ? AND customer_id = ? AND status = 'pending'";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('ii', $pickup_id, $customer_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $success_message = "Permintaan jemput barang telah dibatalkan.";
        } else {
            $error_message = "Gagal membatalkan permintaan. Mungkin permintaan sudah diproses.";
        }
        $stmt->close();
    }
} catch (Exception $e) {
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}

$page_title = 'Dasbor Pelanggan';
include '../templates/header.php';

$requests = [];
$fetch_error = '';

try {
    // Fetch pickup requests by customer_id
    $sql = "SELECT id, customer_address, waste_description, status, created_at FROM pickup_requests WHERE customer_id = ? ORDER BY created_at DESC";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param('i', $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $requests = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (mysqli_sql_exception $e) {
    $fetch_error = "Gagal memuat riwayat permintaan.";
}

?>

<main class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h1 class="h3">Selamat Datang, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h1>
        <div>
            <a href="request_pickup.php" class="btn btn-primary">Request Jemput Barang</a>
            <a href="notifikasi.php" class="btn btn-info">Lihat Notifikasi</a>
        </div>
    </div>
    <p>Gunakan panel ini untuk meminta penjemputan sampah Anda dan melihat riwayatnya.</p>

    <?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>

    <div class="card">
        <div class="card-header">
            <h4>Riwayat Permintaan Jemput Barang</h4>
        </div>
        <div class="card-body">
            <?php if ($fetch_error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($fetch_error); ?></div>
            <?php elseif (empty($requests)): ?>
                <p class="text-center">Belum ada riwayat permintaan jemput barang.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Alamat</th>
                                <th>Deskripsi</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $row): ?>
                                <tr>
                                    <td>#<?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
                                    <td><?php echo htmlspecialchars($row['waste_description'] ?: 'Tidak ada'); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo match($row['status']) {
                                                'pending' => 'warning',
                                                'accepted' => 'info',
                                                'completed' => 'success',
                                                'cancelled' => 'danger',
                                                default => 'secondary'
                                            };
                                        ?>">
                                            <?php echo ucfirst(htmlspecialchars($row['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d M Y, H:i', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <?php if ($row['status'] === 'pending'): ?>
                                            <a href="index.php?action=cancel&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin membatalkan permintaan ini?')">Batal</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php 
include '../templates/footer.php'; 
if (isset($connection)) {
    $connection->close();
}
?>
<?php
/**
 * File: config/database.php
 * Description: Database connection configuration.
 */

// -- Database Settings --
// Replace with your database credentials

// Database host (usually 'localhost' or '127.0.0.1')
define('DB_HOST', 'localhost');

// Your database username
define('DB_USERNAME', 'root');

// Your database password
define('DB_PASSWORD', '');

// The name of the database you created
define('DB_NAME', 'db_kepul_point');


// -- Establish Connection --

// Create a new connection using MySQLi
$connection = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check for connection errors
if ($connection->connect_error) {
    // If the connection fails, stop the script and display an error message.
    // For a production environment, it's better to log this error than to display it to the user.
    die("Connection Failed: " . $connection->connect_error);
}

// Set the character set to utf8mb4 to support a wider range of characters
$connection->set_charset("utf8mb4");

/**
 * You can now include this file in other PHP scripts that need database access
 * using: require_once 'config/database.php';
 */
?>

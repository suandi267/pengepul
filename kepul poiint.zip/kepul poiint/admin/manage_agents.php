<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Security check: Ensure user is a logged-in admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Enable mysqli error reporting
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$action = $_GET['action'] ?? 'list'; // Default action is to list agents
$agent_id = $_GET['id'] ?? null;
$error_message = '';
$success_message = '';

// -- C.R.U.D. LOGIC --

try {
    // CREATE or UPDATE Agent
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_agent'])) {
        // CSRF Token Validation
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Invalid CSRF token.");
        }

        $id = $_POST['id'];
        $name = trim($_POST['name']);
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if (empty($name) || empty($username)) {
            $error_message = "Nama dan username tidak boleh kosong.";
        } else {
            if (empty($id)) { // CREATE
                if (empty($password)) {
                    $error_message = "Password tidak boleh kosong untuk agen baru.";
                } else {
                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                    $sql = "INSERT INTO users (name, username, password, role) VALUES (?, ?, ?, 'agent')";
                    $stmt = $connection->prepare($sql);
                    $stmt->bind_param('sss', $name, $username, $hashed_password);
                    $stmt->execute();
                    $success_message = "Agen baru berhasil ditambahkan.";
                }
            } else { // UPDATE
                if (!empty($password)) {
                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                    $sql = "UPDATE users SET name = ?, username = ?, password = ? WHERE id = ? AND role = 'agent'";
                    $stmt = $connection->prepare($sql);
                    $stmt->bind_param('sssi', $name, $username, $hashed_password, $id);
                } else {
                    $sql = "UPDATE users SET name = ?, username = ? WHERE id = ? AND role = 'agent'";
                    $stmt = $connection->prepare($sql);
                    $stmt->bind_param('ssi', $name, $username, $id);
                }
                $stmt->execute();
                $success_message = "Data agen berhasil diperbarui.";
            }
            $action = 'list'; // Go back to list view after action
        }
    }

    // DELETE Agent
    if ($action === 'delete' && $agent_id) {
        // Also check for CSRF token on delete links
        if (!isset($_GET['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_GET['csrf_token'])) {
            throw new Exception("Invalid CSRF token.");
        }
        $sql = "DELETE FROM users WHERE id = ? AND role = 'agent'";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $agent_id);
        $stmt->execute();
        $success_message = "Agen berhasil dihapus.";
        $action = 'list';
    }
} catch (mysqli_sql_exception $e) {
    // Handle potential duplicate username errors more gracefully
    if ($e->getCode() == 1062) { // 1062 is the MySQL error code for duplicate entry
        $error_message = "Gagal. Username '$username' sudah digunakan.";
    } else {
        $error_message = "Terjadi kesalahan pada database: " . $e->getMessage();
    }
    // Log the full error for debugging: error_log($e->getMessage());
} catch (Exception $e) {
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}


// -- PAGE RENDERING --

$page_title = 'Kelola Agen';
// Admin header
include __DIR__ . '/../templates/admin_header.php';

if ($action === 'list') {
    // READ Agents using prepared statement
    $stmt = $connection->prepare("SELECT id, name, username, created_at FROM users WHERE role = 'agent' ORDER BY name");
    $stmt->execute();
    $result = $stmt->get_result();
?>
    <h2>Daftar Agen</h2>
    <a href="?action=add" class="btn btn-primary mb-3">Tambah Agen Baru</a>
    <?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>
    <table class="table table-striped">
        <thead><tr><th>Nama</th><th>Username</th><th>Bergabung Sejak</th><th>Aksi</th></tr></thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                <td>
                    <a href="?action=edit&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="?action=delete&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus agen ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php
} elseif ($action === 'add' || $action === 'edit') {
    $agent = ['id' => '', 'name' => '', 'username' => ''];
    if ($action === 'edit' && $agent_id) {
        $stmt = $connection->prepare("SELECT id, name, username FROM users WHERE id = ? AND role = 'agent'");
        $stmt->bind_param('i', $agent_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $agent = $result->fetch_assoc();
        if (!$agent) {
             // If agent not found, redirect or show error
            echo '<div class="alert alert-danger">Agen tidak ditemukan.</div>';
include __DIR__ . '/../templates/admin_footer.php';
            exit;
        }
    }
?>
    <h2><?php echo $action === 'add' ? 'Tambah Agen Baru' : 'Edit Agen'; ?></h2>
    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>
    <form method="POST" action="manage_agents.php">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="hidden" name="id" value="<?php echo $agent['id']; ?>">
        <div class="mb-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($agent['name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($agent['username']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password">
            <?php if($action === 'edit'): ?><small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small><?php endif; ?>
        </div>
        <button type="submit" name="save_agent" class="btn btn-success">Simpan</button>
        <a href="manage_agents.php" class="btn btn-secondary">Batal</a>
    </form>
<?php
}

// Admin footer
include __DIR__ . '/../templates/admin_footer.php';
?>

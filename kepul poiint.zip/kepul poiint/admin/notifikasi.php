<?php
session_start();
require_once '../config/database.php';

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Security check: Ensure user is a logged-in admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$admin_id = $_SESSION['user_id'];
$error_message = '';
$success_message = '';

try {
    $action = $_GET['action'] ?? null;
    $csrf_token = $_GET['csrf_token'] ?? null;

    // CSRF Check for all GET actions
    if ($action && (!hash_equals($_SESSION['csrf_token'], $csrf_token))) {
        throw new Exception("Sesi tidak valid. Silakan coba lagi.");
    }

    // Mark a notification as read
    if ($action === 'mark_read' && isset($_GET['id'])) {
        $notification_id = (int)$_GET['id'];
        $stmt = $connection->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param('ii', $notification_id, $admin_id);
        $stmt->execute();
        $stmt->close();

        // --- Open Redirect Fix ---
        $redirect_link = 'notifikasi.php'; // Default redirect
        if (isset($_GET['link'])) {
            $unsafe_link = $_GET['link'];
            // Whitelist of allowed pages for redirection
            $allowed_pages = ['laporan_transaksi.php', 'manage_agents.php', 'manage_items.php', 'manage_prices.php'];
            $parsed_url = parse_url($unsafe_link, PHP_URL_PATH);
            if (in_array(basename($parsed_url), $allowed_pages)) {
                $redirect_link = $unsafe_link;
            }
        }
        header("Location: " . $redirect_link);
        exit;
    }

    // Notify agents about new pickup requests
    if ($action === 'notify_agents' && isset($_GET['pickup_id'])) {
        $pickup_id = (int)$_GET['pickup_id'];
        
        $connection->begin_transaction();

        $message = "Permintaan jemput barang baru #{$pickup_id} tersedia untuk diterima.";
        $link = "../agent/jemput_barang.php?pickup_id={$pickup_id}";
        $notif_sql = "INSERT INTO notifications (user_id, message, link) SELECT id, ?, ? FROM users WHERE role = 'agent'";
        $notif_stmt = $connection->prepare($notif_sql);
        $notif_stmt->bind_param('ss', $message, $link);
        $notif_stmt->execute();
        $notif_stmt->close();

        $connection->commit();
        $success_message = "Notifikasi telah dikirim ke semua agen.";
        // Redirect back to the main notifications page to prevent re-triggering on refresh
        header("Location: notifikasi.php?success=" . urlencode($success_message));
        exit;
    }

} catch (Exception $e) {
    if (isset($connection) && $connection->in_transaction) {
        $connection->rollback();
    }
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}

// Display messages from GET parameters
if(isset($_GET['success'])) $success_message = htmlspecialchars($_GET['success']);
if(isset($_GET['error'])) $error_message = htmlspecialchars($_GET['error']);


$page_title = 'Notifikasi';
include '../templates/admin_header.php';
?>

<h2><?php echo htmlspecialchars($page_title); ?></h2>
<p>Berikut adalah daftar notifikasi untuk Anda.</p>

<?php if($success_message) echo '<div class="alert alert-success">'.$success_message.'</div>'; ?>
<?php if($error_message) echo '<div class="alert alert-danger">'.$error_message.'</div>'; ?>

<div class="list-group">
    <?php 
    try {
        $stmt = $connection->prepare("SELECT id, message, is_read, link, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->bind_param('i', $admin_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0): 
            while($row = $result->fetch_assoc()): 
    ?>
            <a href="notifikasi.php?action=mark_read&id=<?php echo $row['id']; ?>&link=<?php echo urlencode($row['link']); ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
               class="list-group-item list-group-item-action <?php echo $row['is_read'] ? 'list-group-item-light text-muted' : 'list-group-item-warning'; ?>">
                <div class="d-flex w-100 justify-content-between">
                    <p class="mb-1"><?php echo htmlspecialchars($row['message']); ?></p>
                    <small class="text-nowrap"><?php echo date('d M Y, H:i', strtotime($row['created_at'])); ?></small>
                </div>
                <small><?php echo $row['is_read'] ? 'Sudah dibaca' : 'Klik untuk tandai sebagai sudah dibaca.'; ?></small>
            </a>
    <?php 
            endwhile; 
        else: 
    ?>
        <div class="list-group-item text-center">Tidak ada notifikasi.</div>
    <?php 
        endif; 
        $stmt->close();
    } catch (mysqli_sql_exception $e) {
        echo '<div class="list-group-item text-center text-danger">Gagal memuat notifikasi.</div>';
    }
    ?>
</div>

<?php
include '../templates/admin_footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
<?php
// Start session and check if user is an admin
session_start();

// If user is not logged in or is not an admin, redirect to login page
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Include necessary files
require_once '../config/database.php';

// Set the page title
$page_title = 'Dashboard Admin';

// --- Data Fetching for Dashboard ---

// 1. KPI: Total Users (Agents + Customers)
$total_users_sql = "SELECT COUNT(id) as total FROM users WHERE role IN ('agent', 'customer')";
$total_users_result = $connection->query($total_users_sql);
$total_users = $total_users_result->fetch_assoc()['total'];

// 2. KPI: Pending Pickup Requests
$pending_pickups_sql = "SELECT COUNT(id) as total FROM pickup_requests WHERE status = 'pending'";
$pending_pickups_result = $connection->query($pending_pickups_sql);
$pending_pickups = $pending_pickups_result->fetch_assoc()['total'];

// 3. KPI: Total Transactions
$total_transactions_sql = "SELECT COUNT(id) as total FROM transactions";
$total_transactions_result = $connection->query($total_transactions_sql);
$total_transactions = $total_transactions_result->fetch_assoc()['total'];

// 4. KPI: Total Weight Collected (in Kg)
$total_weight_sql = "SELECT SUM(weight_kg) as total FROM transactions WHERE status = 'selesai'";
$total_weight_result = $connection->query($total_weight_sql);
$total_weight = $total_weight_result->fetch_assoc()['total'] ?? 0;


// Include the admin-specific header
include '../templates/admin_header.php';

?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="h2">Dashboard</h1>
        <p class="text-muted">Selamat Datang, <?php echo htmlspecialchars($_SESSION['name']); ?>! Berikut adalah ringkasan aktivitas sistem.</p>
    </div>
</div>

<!-- KPI Cards -->
<div class="row g-4 mb-5">
    <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
            <div class="card-body">
                <div class="kpi-icon icon-users"><i class="fas fa-users"></i></div>
                <div>
                    <p class="kpi-value"><?php echo $total_users; ?></p>
                    <p class="kpi-label">Total Pengguna</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
            <div class="card-body">
                <div class="kpi-icon icon-transactions"><i class="fas fa-exchange-alt"></i></div>
                <div>
                    <p class="kpi-value"><?php echo $total_transactions; ?></p>
                    <p class="kpi-label">Total Transaksi</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
            <div class="card-body">
                <div class="kpi-icon icon-pickups"><i class="fas fa-truck-loading"></i></div>
                <div>
                    <p class="kpi-value"><?php echo $pending_pickups; ?></p>
                    <p class="kpi-label">Permintaan Jemput</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
            <div class="card-body">
                <div class="kpi-icon icon-weight"><i class="fas fa-weight-hanging"></i></div>
                <div>
                    <p class="kpi-value"><?php echo number_format($total_weight, 2); ?> Kg</p>
                    <p class="kpi-label">Total Sampah Terkumpul</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Content Area -->
<div class="row g-4">
    <!-- Quick Actions -->
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">Aksi Cepat</div>
            <div class="list-group list-group-flush">
                <a href="manage_agents.php" class="list-group-item list-group-item-action"><i class="fas fa-users-cog me-2"></i>Kelola Agen</a>
                <a href="manage_prices.php" class="list-group-item list-group-item-action"><i class="fas fa-dollar-sign me-2"></i>Kelola Harga</a>
                <a href="laporan_transaksi.php" class="list-group-item list-group-item-action"><i class="fas fa-file-alt me-2"></i>Lihat Laporan</a>
                <a href="notifikasi.php" class="list-group-item list-group-item-action"><i class="fas fa-bell me-2"></i>Lihat Notifikasi</a>
            </div>
        </div>
    </div>
</div>

<?php
// Include the admin-specific footer
include '../templates/admin_footer.php';
?>
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Security check: Ensure user is a logged-in admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$error_message = '';
$success_message = '';

try {
    // Handle status update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $transaction_id = (int)$_POST['transaction_id'];
        $new_status = $_POST['status'];
        $allowed_statuses = ['disetor', 'diproses', 'selesai'];

        if (in_array($new_status, $allowed_statuses)) {
            $sql = "UPDATE transactions SET status = ? WHERE id = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('si', $new_status, $transaction_id);
            $stmt->execute();
            $stmt->close();
            $success_message = "Status transaksi #{$transaction_id} berhasil diperbarui.";
        } else {
            $error_message = "Status tidak valid.";
        }
    }
} catch (Exception $e) {
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}

$page_title = 'Laporan Transaksi';
include __DIR__ . '/../templates/admin_header.php';
?>

<h2><?php echo htmlspecialchars($page_title); ?></h2>
<p>Berikut adalah riwayat semua transaksi yang tercatat di sistem.</p>

<?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
<?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Tanggal</th>
                        <th>Agen</th>
                        <th>Pelanggan</th>
                        <th>Jenis Sampah</th>
                        <th>Berat (Kg)</th>
                        <th>Total Harga</th>
                        <th>Total Poin</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    try {
                        // READ all transactions with user and waste type details
                        $sql = "SELECT 
                                    t.id, t.weight_kg, t.total_price, t.total_points, t.status, t.transaction_date, 
                                    agent.name as agent_name, 
                                    COALESCE(customer.name, t.customer_name) as customer_display_name,
                                    wt.name as waste_type_name
                                FROM transactions t
                                JOIN users agent ON t.agent_id = agent.id
                                LEFT JOIN users customer ON t.customer_id = customer.id
                                JOIN waste_types wt ON t.waste_type_id = wt.id
                                ORDER BY t.transaction_date DESC";
                        $stmt = $connection->prepare($sql);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result && $result->num_rows > 0): 
                            while($row = $result->fetch_assoc()): 
                    ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo date('d M Y, H:i', strtotime($row['transaction_date'])); ?></td>
                            <td><?php echo htmlspecialchars($row['agent_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['customer_display_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['waste_type_name']); ?></td>
                            <td><?php echo number_format($row['weight_kg'], 2); ?></td>
                            <td>Rp <?php echo number_format($row['total_price'], 0); ?></td>
                            <td><?php echo number_format($row['total_points']); ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo match($row['status']) {
                                        'disetor' => 'secondary',
                                        'diproses' => 'info',
                                        'selesai' => 'success',
                                        default => 'light'
                                    };
                                ?>">
                                    <?php echo ucfirst(htmlspecialchars($row['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" action="laporan_transaksi.php" class="d-inline-flex align-items-center">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    <input type="hidden" name="transaction_id" value="<?php echo $row['id']; ?>">
                                    <select name="status" class="form-select form-select-sm me-1" style="width: auto;">
                                        <option value="disetor" <?php if($row['status']=='disetor') echo 'selected'; ?>>Disetor</option>
                                        <option value="diproses" <?php if($row['status']=='diproses') echo 'selected'; ?>>Diproses</option>
                                        <option value="selesai" <?php if($row['status']=='selesai') echo 'selected'; ?>>Selesai</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-sm btn-primary">Ubah</button>
                                </form>
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        else: 
                        ?>
                            <tr><td colspan="10" class="text-center">Belum ada transaksi yang tercatat.</td></tr>
                    <?php 
                        endif; 
                        $stmt->close();
                    } catch (mysqli_sql_exception $e) {
                        echo '<tr><td colspan="10" class="text-center text-danger">Gagal memuat data transaksi.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
include __DIR__ . '/../templates/admin_footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
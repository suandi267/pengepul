<?php
session_start();
include_once '../config/database.php';

// Pastikan hanya admin yang bisa mengakses halaman ini
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$page_title = "Rekap Pendapatan";
include_once '../templates/admin_header.php';

$total_income = 0;
$chart_labels = [];
$chart_data = [];
$transactions = [];
$error_message = '';

try {
    // Ambil data total pendapatan
    $stmt_total = $connection->prepare("SELECT SUM(total_price) AS total_income FROM transactions WHERE status = 'selesai'");
    $stmt_total->execute();
    $result_total = $stmt_total->get_result();
    $total_income_data = $result_total->fetch_assoc();
    $total_income = $total_income_data['total_income'] ?? 0;
    $stmt_total->close();

    // Ambil data pendapatan per hari untuk 7 hari terakhir
    $seven_days_ago = date('Y-m-d', strtotime("-6 days"));
    $stmt_chart = $connection->prepare("SELECT DATE(transaction_date) as date, SUM(total_price) as daily_income 
                                       FROM transactions 
                                       WHERE status = 'selesai' AND transaction_date >= ?
                                       GROUP BY DATE(transaction_date)
                                       ORDER BY DATE(transaction_date) ASC");
    $stmt_chart->bind_param('s', $seven_days_ago);
    $stmt_chart->execute();
    $result_chart = $stmt_chart->get_result();
    $daily_incomes = $result_chart->fetch_all(MYSQLI_ASSOC);
    $stmt_chart->close();

    // Inisialisasi 7 hari terakhir dengan pendapatan 0
    $dates = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $dates[date("d M", strtotime($date))] = 0;
    }

    foreach ($daily_incomes as $income) {
        $formatted_date = date("d M", strtotime($income['date']));
        if (isset($dates[$formatted_date])) {
            $dates[$formatted_date] = (float)$income['daily_income'];
        }
    }
    $chart_labels = array_keys($dates);
    $chart_data = array_values($dates);

    // Ambil semua data transaksi
    $stmt_transactions = $connection->prepare("SELECT t.id, u.name as agent_name, t.customer_name, wt.name as waste_type, t.weight_kg, t.total_price, t.transaction_date 
                                             FROM transactions t
                                             JOIN users u ON t.agent_id = u.id
                                             JOIN waste_types wt ON t.waste_type_id = wt.id
                                             WHERE t.status = 'selesai'
                                             ORDER BY t.transaction_date DESC");
    $stmt_transactions->execute();
    $result_transactions = $stmt_transactions->get_result();
    $transactions = $result_transactions->fetch_all(MYSQLI_ASSOC);
    $stmt_transactions->close();

} catch (mysqli_sql_exception $e) {
    $error_message = "Gagal memuat data rekap pendapatan: " . $e->getMessage();
}

?>

<div class="container-fluid">
    <h1 class="my-4">Rekap Pendapatan</h1>
    <a href="notifikasi.php" class="btn btn-info mb-4">Lihat Notifikasi</a>

    <?php if($error_message): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-white bg-success mb-3 h-100">
                    <div class="card-header fw-bold">Total Pendapatan (Selesai)</div>
                    <div class="card-body d-flex align-items-center justify-content-center">
                        <h3 class="card-title mb-0">Rp <?php echo number_format($total_income, 2, ',', '.'); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header fw-bold">Pendapatan 7 Hari Terakhir (Selesai)</div>
                    <div class="card-body">
                        <canvas id="incomeChart" style="height: 250px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <h2 class="my-4">Detail Transaksi (Selesai)</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Nama Agen</th>
                        <th>Nama Pelanggan</th>
                        <th>Jenis Sampah</th>
                        <th>Berat (kg)</th>
                        <th>Total Harga</th>
                        <th>Tanggal Transaksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($transactions)): ?>
                        <?php foreach($transactions as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['agent_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['waste_type']); ?></td>
                                <td><?php echo number_format($row['weight_kg'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['total_price'], 2, ',', '.'); ?></td>
                                <td><?php echo date("d M Y, H:i", strtotime($row['transaction_date'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data transaksi yang selesai.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Only run chart script if the chart canvas exists
    const chartCanvas = document.getElementById('incomeChart');
    if (chartCanvas) {
        const ctx = chartCanvas.getContext('2d');
        const incomeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($chart_labels, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>,
                datasets: [{
                    label: 'Pendapatan Harian',
                    data: <?php echo json_encode($chart_data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>,
                    backgroundColor: 'rgba(40, 167, 69, 0.6)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) label += ': ';
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    },
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
});
</script>

<?php
include_once '../templates/admin_footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
<?php
session_start();
require_once '../config/database.php';

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Security check: Ensure user is a logged-in admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$action = $_GET['action'] ?? 'list';
$item_id = $_GET['id'] ?? null;
$error_message = '';
$success_message = '';

try {
    // CREATE or UPDATE Item
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_item'])) {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $id = $_POST['id'];
        $name = trim($_POST['name']);
        $price_per_kg = filter_var($_POST['price_per_kg'], FILTER_VALIDATE_FLOAT);
        $points_per_kg = filter_var($_POST['points_per_kg'], FILTER_VALIDATE_INT);
        $current_image = $_POST['current_image'] ?? '';

        if (empty($name) || $price_per_kg === false || $points_per_kg === false) {
            throw new Exception("Nama, harga, dan poin harus diisi dengan format yang benar.");
        }

        $image_filename = $current_image;
        // Handle file upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/images/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $file_info = new finfo(FILEINFO_MIME_TYPE);
            $mime_type = $file_info->file($_FILES['image']['tmp_name']);
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

            if (in_array($mime_type, $allowed_types)) {
                if ($_FILES['image']['size'] < 2000000) { // 2MB limit
                    $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                    $new_filename = bin2hex(random_bytes(16)) . '.' . $file_extension;
                    $target_file = $upload_dir . $new_filename;

                    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                        // Delete old image if it exists and is not a placeholder
                        if (!empty($current_image) && file_exists($upload_dir . $current_image)) {
                            unlink($upload_dir . $current_image);
                        }
                        $image_filename = $new_filename;
                    } else {
                        throw new Exception("Gagal memindahkan file.");
                    }
                } else {
                    throw new Exception("Ukuran file maksimal 2MB.");
                }
            } else {
                throw new Exception("Format file tidak valid (hanya JPG, PNG, GIF).");
            }
        }

        if (empty($id)) { // CREATE
            $sql = "INSERT INTO waste_types (name, price_per_kg, points_per_kg, image) VALUES (?, ?, ?, ?)";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('sdis', $name, $price_per_kg, $points_per_kg, $image_filename);
            $success_message = "Barang baru berhasil ditambahkan.";
        } else { // UPDATE
            $sql = "UPDATE waste_types SET name = ?, price_per_kg = ?, points_per_kg = ?, image = ? WHERE id = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('sdisi', $name, $price_per_kg, $points_per_kg, $image_filename, $id);
            $success_message = "Data barang berhasil diperbarui.";
        }
        $stmt->execute();
        $stmt->close();
        $action = 'list';
    }

    // DELETE Item
    if ($action === 'delete' && $item_id) {
        if (!isset($_GET['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_GET['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }
        // First, get the image filename to delete the file
        $stmt = $connection->prepare("SELECT image FROM waste_types WHERE id = ?");
        $stmt->bind_param('i', $item_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $item = $result->fetch_assoc();
        $stmt->close();

        if ($item && !empty($item['image'])) {
            $image_path = '../uploads/images/' . $item['image'];
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }

        $sql = "DELETE FROM waste_types WHERE id = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $item_id);
        $stmt->execute();
        $stmt->close();
        $success_message = "Barang berhasil dihapus.";
        $action = 'list';
    }
} catch (Exception $e) {
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}

$page_title = 'Kelola Barang (Jenis Sampah)';
include '../templates/admin_header.php';

if ($action === 'list'):
    $stmt = $connection->prepare("SELECT id, name, price_per_kg, points_per_kg, image FROM waste_types ORDER BY name ASC");
    $stmt->execute();
    $result = $stmt->get_result();
?>
    <h2>Daftar Barang</h2>
    <a href="?action=add" class="btn btn-primary mb-3">Tambah Barang Baru</a>
    <?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark"><tr><th>ID</th><th>Gambar</th><th>Nama</th><th>Harga/KG</th><th>Poin/KG</th><th class="text-end">Aksi</th></tr></thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <?php 
                                    $image_path = '../uploads/images/' . htmlspecialchars($row['image'] ?? '');
                                    if (empty($row['image']) || !file_exists($image_path)) {
                                        $image_path = 'https://via.placeholder.com/80x60.png?text=' . urlencode($row['name']);
                                    }
                                ?>
                                <img src="<?php echo $image_path; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" style="width: 80px; height: 60px; object-fit: cover; border-radius: 5px;">
                            </td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td>Rp <?php echo number_format($row['price_per_kg'], 0, ',', '.'); ?></td>
                            <td><?php echo number_format($row['points_per_kg']); ?></td>
                            <td class="text-end">
                                <a href="?action=edit&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Ubah</a>
                                <a href="?action=delete&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus barang ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr><td colspan="6" class="text-center">Belum ada data barang.</td></tr>
                        <?php endif; 
                        $stmt->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php
elseif ($action === 'add' || $action === 'edit'):
    $item = ['id' => '', 'name' => '', 'price_per_kg' => '', 'points_per_kg' => '', 'image' => ''];
    if ($action === 'edit' && $item_id) {
        $stmt = $connection->prepare("SELECT id, name, price_per_kg, points_per_kg, image FROM waste_types WHERE id = ?");
        $stmt->bind_param('i', $item_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $item = $result->fetch_assoc();
        $stmt->close();
    }
?>
    <h2><?php echo $action === 'add' ? 'Tambah Barang Baru' : 'Edit Barang'; ?></h2>
    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>
    <form method="POST" action="manage_items.php" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
        <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($item['image']); ?>">
        <div class="mb-3">
            <label for="name" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($item['name']); ?>" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="price_per_kg" class="form-label">Harga per KG (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="price_per_kg" name="price_per_kg" value="<?php echo htmlspecialchars($item['price_per_kg']); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="points_per_kg" class="form-label">Poin per KG</label>
                <input type="number" class="form-control" id="points_per_kg" name="points_per_kg" value="<?php echo htmlspecialchars($item['points_per_kg']); ?>" required>
            </div>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Gambar Barang</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/jpeg,image/png,image/gif">
            <?php if ($action === 'edit' && !empty($item['image'])): 
                $image_path = '../uploads/images/' . htmlspecialchars($item['image']);
                if (file_exists($image_path)):
            ?>
                <div class="mt-2">
                    <small>Gambar saat ini:</small><br>
                    <img src="<?php echo $image_path; ?>" alt="Current Image" style="max-width: 150px; border-radius: 5px;">
                </div>
            <?php endif; endif; ?>
            <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah gambar.</small>
        </div>
        <button type="submit" name="save_item" class="btn btn-success">Simpan</button>
        <a href="manage_items.php" class="btn btn-secondary">Batal</a>
    </form>
<?php
endif;

include '../templates/admin_footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
<?php
session_start();
require_once '../config/database.php';

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Security check: Ensure user is a logged-in admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$error_message = '';
$success_message = '';

try {
    // UPDATE prices and points logic
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_prices'])) {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $prices = $_POST['prices'] ?? [];
        $points = $_POST['points'] ?? [];
        
        $connection->begin_transaction();

        $sql = "UPDATE waste_types SET price_per_kg = ?, points_per_kg = ? WHERE id = ?";
        $stmt = $connection->prepare($sql);

        foreach ($prices as $id => $price) {
            $id = filter_var($id, FILTER_VALIDATE_INT);
            $price = filter_var($price, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE) ?? 0.0;
            $point = filter_var($points[$id] ?? null, FILTER_VALIDATE_INT, FILTER_NULL_ON_FAILURE) ?? 0;

            if ($id === false) continue; // Skip if ID is not a valid integer

            $stmt->bind_param('dii', $price, $point, $id);
            $stmt->execute();
        }
        $stmt->close();

        $connection->commit();
        $success_message = "Semua harga dan poin berhasil diperbarui.";
    }
} catch (Exception $e) {
    if (isset($connection) && $connection->in_transaction) {
        $connection->rollback();
    }
    $error_message = "Terjadi kesalahan: " . $e->getMessage();
}

// -- PAGE RENDERING --
$page_title = 'Kelola Harga & Poin Sampah';
include '../templates/admin_header.php';
?>

<h2><?php echo htmlspecialchars($page_title); ?></h2>
<p>Perbarui harga dan poin per kilogram (Rp) untuk setiap jenis sampah.</p>

<?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
<?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>

<form method="POST" action="manage_prices.php">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Jenis Sampah</th>
                            <th style="width: 200px;">Harga per KG (Rp)</th>
                            <th style="width: 150px;">Poin per KG</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        try {
                            $stmt = $connection->prepare("SELECT id, name, price_per_kg, points_per_kg FROM waste_types ORDER BY name ASC");
                            $stmt->execute();
                            $result = $stmt->get_result();
                            while($row = $result->fetch_assoc()): 
                        ?>
                        <tr>
                            <td>
                                <label for="price_<?php echo $row['id']; ?>" class="form-label fw-bold">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </label>
                            </td>
                            <td>
                                <input type="number" step="50" min="0" class="form-control"
                                    id="price_<?php echo $row['id']; ?>"
                                    name="prices[<?php echo $row['id']; ?>]"
                                    value="<?php echo htmlspecialchars($row['price_per_kg'] ?? '0'); ?>">
                            </td>
                            <td>
                                <input type="number" step="1" min="0" class="form-control"
                                    id="points_<?php echo $row['id']; ?>"
                                    name="points[<?php echo $row['id']; ?>]"
                                    value="<?php echo htmlspecialchars($row['points_per_kg'] ?? '0'); ?>">
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                            $stmt->close();
                        } catch (mysqli_sql_exception $e) {
                            echo '<tr><td colspan="3" class="text-center text-danger">Gagal memuat data harga.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer text-end">
            <button type="submit" name="update_prices" class="btn btn-success">Simpan Perubahan</button>
        </div>
    </div>
</form>

<?php
include '../templates/admin_footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
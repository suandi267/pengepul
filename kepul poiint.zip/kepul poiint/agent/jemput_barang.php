<?php
session_start();

// Security check: Ensure user is a logged-in agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$agent_id = $_SESSION['user_id'];
$error_message = '';
$success_message = '';

try {
    // Handle actions: accept, complete, cancel
    if (isset($_GET['action']) && isset($_GET['id'])) {
        if (!isset($_GET['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_GET['csrf_token'])) {
            throw new Exception("Sesi tidak valid. Silakan coba lagi.");
        }

        $pickup_id = (int)$_GET['id'];
        $action = $_GET['action'];

        $connection->begin_transaction();

        if ($action === 'accept') {
            // Atomically check and update the status
            $sql = "UPDATE pickup_requests SET status = 'accepted', agent_id = ? WHERE id = ? AND status = 'pending'";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('ii', $agent_id, $pickup_id);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $success_message = "Permintaan jemput barang telah diterima.";
            } else {
                throw new Exception("Gagal menerima permintaan. Mungkin sudah diambil agen lain.");
            }
        } elseif ($action === 'complete') {
            $sql = "UPDATE pickup_requests SET status = 'completed' WHERE id = ? AND agent_id = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('ii', $pickup_id, $agent_id);
            $stmt->execute();
            $success_message = "Permintaan jemput barang telah diselesaikan.";
        } elseif ($action === 'cancel') {
            // Allow agent to cancel an accepted request, returning it to the pending pool
            $sql = "UPDATE pickup_requests SET status = 'pending', agent_id = NULL WHERE id = ? AND agent_id = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param('ii', $pickup_id, $agent_id);
            $stmt->execute();
            $success_message = "Permintaan jemput barang telah dikembalikan ke daftar tunggu.";
        }
        $stmt->close();
        $connection->commit();
        // Redirect to clean the URL and prevent re-submission
        header("Location: jemput_barang.php?success=" . urlencode($success_message));
        exit;
    }
} catch (Exception $e) {
    if (isset($connection) && $connection->in_transaction) {
        $connection->rollback();
    }
    // Redirect with an error message
    header("Location: jemput_barang.php?error=" . urlencode($e->getMessage()));
    exit;
}

// Display messages from GET parameters
if(isset($_GET['success'])) $success_message = htmlspecialchars($_GET['success']);
if(isset($_GET['error'])) $error_message = htmlspecialchars($_GET['error']);

$page_title = 'Jemput Barang';
include '../templates/header.php';

// Fetch transaction summary for the agent
$transactions = [];
$total_income = 0;
$transaction_error = '';
try {
    $sql_trans = "SELECT t.customer_name, wt.name as waste_type, t.weight_kg, t.total_price, t.transaction_date
                  FROM transactions t
                  JOIN waste_types wt ON t.waste_type_id = wt.id
                  WHERE t.agent_id = ?
                  ORDER BY t.transaction_date DESC";
    $stmt_trans = $connection->prepare($sql_trans);
    $stmt_trans->bind_param('i', $agent_id);
    $stmt_trans->execute();
    $result_trans = $stmt_trans->get_result();
    $transactions = $result_trans->fetch_all(MYSQLI_ASSOC);
    $stmt_trans->close();

    // Calculate total income
    foreach ($transactions as $transaction) {
        $total_income += $transaction['total_price'];
    }
} catch (mysqli_sql_exception $e) {
    $transaction_error = "Gagal memuat data setoran: " . $e->getMessage();
}


$requests = [];
$fetch_error = '';
try {
    // Fetch requests that are pending OR are assigned to THIS agent.
    // Added latitude and longitude to the selection.
    $sql = "SELECT id, customer_name, customer_phone, customer_address, waste_description, photo_url, status, created_at, agent_id, latitude, longitude 
            FROM pickup_requests 
            WHERE status = 'pending' OR (agent_id = ? AND status IN ('accepted', 'cancelled'))
            ORDER BY created_at DESC";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param('i', $agent_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $requests = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (mysqli_sql_exception $e) {
    $fetch_error = "Gagal memuat data permintaan.";
}

?>

<main class="container my-5">
    
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="mb-0">Rekap Setoran Anda</h4>
        </div>
        <div class="card-body">
            <?php if($transaction_error): ?>
                <div class="alert alert-danger"><?php echo $transaction_error; ?></div>
            <?php else: ?>
                <h5 class="card-title">Total Pendapatan: Rp <?php echo number_format($total_income, 2, ',', '.'); ?></h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Nama Konsumen</th>
                                <th>Jenis Sampah</th>
                                <th>Berat (Kg)</th>
                                <th>Total Harga</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($transactions)): ?>
                                <?php foreach ($transactions as $trans): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($trans['customer_name']); ?></td>
                                        <td><?php echo htmlspecialchars($trans['waste_type']); ?></td>
                                        <td><?php echo htmlspecialchars($trans['weight_kg']); ?></td>
                                        <td>Rp <?php echo number_format($trans['total_price'], 2, ',', '.'); ?></td>
                                        <td><?php echo date('d M Y, H:i', strtotime($trans['transaction_date'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Belum ada data setoran.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <h2><?php echo htmlspecialchars($page_title); ?></h2>
    <p>Kelola permintaan jemput barang dari pelanggan.</p>

    <?php if($success_message) echo '<div class="alert alert-success">'.$success_message.'</div>'; ?>
    <?php if($error_message) echo '<div class="alert alert-danger">'.$error_message.'</div>'; ?>
    <?php if($fetch_error) echo '<div class="alert alert-danger">'.$fetch_error.'</div>'; ?>

    <div class="row">
        <?php if (!empty($requests)): ?>
            <?php foreach($requests as $row): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-header fw-bold">
                            <?php echo htmlspecialchars($row['customer_name']); ?>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <strong>HP:</strong> <?php echo htmlspecialchars($row['customer_phone']); ?><br>
                                <strong>Alamat:</strong> <?php echo nl2br(htmlspecialchars($row['customer_address'])); ?><br>
                                <strong>Deskripsi:</strong> <?php echo nl2br(htmlspecialchars($row['waste_description'] ?: 'Tidak ada')); ?><br>
                                <strong>Dibuat:</strong> <?php echo date('d M Y, H:i', strtotime($row['created_at'])); ?>
                            </p>
                            
                            <?php if ($row['latitude'] && $row['longitude']): ?>
                                <div class="map-container mt-3" id="map-<?php echo $row['id']; ?>" style="height: 300px; display: none; z-index: 1;"></div>
                            <?php endif; ?>

                            <?php if ($row['photo_url']): ?>
                                <a href="../uploads/images/<?php echo htmlspecialchars($row['photo_url']); ?>" target="_blank">
                                    <img src="../uploads/images/<?php echo htmlspecialchars($row['photo_url']); ?>" class="img-fluid rounded my-3" alt="Foto Barang">
                                </a>
                            <?php endif; ?>

                            <?php if ($row['latitude'] && $row['longitude']): ?>
                                <button class="btn btn-outline-primary btn-sm mt-2 show-map-btn"
                                        data-map-id="map-<?php echo $row['id']; ?>"
                                        data-lat="<?php echo $row['latitude']; ?>"
                                        data-lon="<?php echo $row['longitude']; ?>">
                                    Lihat Peta
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                             <span class="badge bg-<?php 
                                echo match($row['status']) {
                                    'pending' => 'warning',
                                    'accepted' => 'info',
                                    'completed' => 'success',
                                    'cancelled' => 'danger',
                                    default => 'secondary'
                                };
                            ?>">
                                <?php echo ucfirst(htmlspecialchars($row['status'])); ?>
                            </span>
                            <div class="btn-group">
                                <?php if ($row['status'] == 'pending'): ?>
                                    <a href="jemput_barang.php?action=accept&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-success btn-sm">Terima</a>
                                <?php elseif ($row['status'] == 'accepted' && $row['agent_id'] == $agent_id): ?>
                                    <a href="jemput_barang.php?action=complete&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-primary btn-sm">Selesaikan</a>
                                    <a href="jemput_barang.php?action=cancel&id=<?php echo $row['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-danger btn-sm">Batalkan</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info text-center">Tidak ada permintaan jemput barang yang tersedia.</div>
            </div>
        <?php endif; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const mapInstances = {};

    document.querySelectorAll('.show-map-btn').forEach(button => {
        button.addEventListener('click', function() {
            const mapId = this.dataset.mapId;
            const lat = parseFloat(this.dataset.lat);
            const lon = parseFloat(this.dataset.lon);
            const mapContainer = document.getElementById(mapId);

            if (!mapContainer) return;

            // Toggle display
            const isHidden = mapContainer.style.display === 'none';
            mapContainer.style.display = isHidden ? 'block' : 'none';
            this.textContent = isHidden ? 'Sembunyikan Peta' : 'Lihat Peta';

            // Initialize map only once
            if (isHidden && !mapInstances[mapId]) {
                const map = L.map(mapId).setView([lat, lon], 15);
                mapInstances[mapId] = map; // Store instance

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                }).addTo(map);

                L.marker([lat, lon]).addTo(map)
                    .bindPopup('Perkiraan lokasi customer.')
                    .openPopup();
                
                // Invalidate size after showing the container
                setTimeout(() => map.invalidateSize(), 10);
            }
        });
    });
});
</script>

<?php
include '../templates/footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
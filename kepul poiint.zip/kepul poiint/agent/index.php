<?php
session_start();

// Security check: Ensure user is a logged-in agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$page_title = 'Dasbor Agen';
include '../templates/header.php';

$waste_types = [];
$error_message = '';

try {
    // Fetch the price list data
    $stmt = $connection->prepare("SELECT name, price_per_kg, points_per_kg FROM waste_types ORDER BY name ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    $waste_types = $result->fetch_all(MYSQLI_ASSOC);
} catch (mysqli_sql_exception $e) {
    $error_message = "Gagal memuat daftar harga. Silakan coba lagi nanti.";
    // For debugging: error_log($e->getMessage());
}

?>

<main class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h1 class="h3">Selamat Datang, Agen <?php echo htmlspecialchars($_SESSION['name']); ?>!</h1>
        <div class="d-flex flex-wrap gap-2">
            <a href="setor_sampah.php" class="btn btn-primary">Catat Setoran Baru</a>
            <a href="jemput_barang.php" class="btn btn-success">Jemput Barang</a>
            <a href="notifikasi.php" class="btn btn-info">Notifikasi</a>
        </div>
    </div>
    <p>Gunakan panel ini untuk mencatat transaksi baru dan melihat riwayat setoran Anda. Berikut adalah daftar harga sampah terbaru yang berlaku saat ini.</p>

    <?php if($error_message): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
    <?php else: ?>
        <div class="card">
            <div class="card-header">
                <h4>Daftar Harga & Poin Sampah</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Jenis Sampah</th>
                                <th>Harga per KG (Rp)</th>
                                <th>Poin per KG</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($waste_types)): ?>
                                <?php foreach ($waste_types as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo number_format($row['price_per_kg'], 2, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($row['points_per_kg']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan='3' class='text-center'>Data harga tidak tersedia.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php 
include '../templates/footer.php'; 

if (isset($connection)) {
    $connection->close();
}
?>
<?php
session_start();

// Security check: Ensure user is a logged-in agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error_message = '';
$success_message = '';
$customer_name = '';
$waste_type_id = '';
$weight_kg = '';

// Fetch waste types for the dropdown
$waste_types = [];
$fetch_error = '';
try {
    $stmt = $connection->prepare("SELECT id, name, price_per_kg, points_per_kg FROM waste_types ORDER BY name");
    $stmt->execute();
    $result = $stmt->get_result();
    $waste_types = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (mysqli_sql_exception $e) {
    $fetch_error = "Gagal memuat jenis sampah.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_transaction'])) {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error_message = "Sesi tidak valid. Silakan coba lagi.";
    } else {
        $customer_name = trim($_POST['customer_name']);
        $waste_type_id = (int)$_POST['waste_type_id'];
        $weight_kg = (float)$_POST['weight_kg'];
        $agent_id = $_SESSION['user_id'];

        if (empty($customer_name) || empty($waste_type_id) || $weight_kg <= 0) {
            $error_message = "Semua field harus diisi dan berat harus lebih dari 0.";
        } else {
            try {
                // Get price and points for the selected waste type
                $stmt = $connection->prepare("SELECT price_per_kg, points_per_kg FROM waste_types WHERE id = ?");
                $stmt->bind_param('i', $waste_type_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $waste_type = $result->fetch_assoc();
                $stmt->close();

                if ($waste_type) {
                    $total_price = $weight_kg * $waste_type['price_per_kg'];
                    $total_points = $weight_kg * $waste_type['points_per_kg'];

                    $connection->begin_transaction();

                    // Insert into transactions
                    $sql_trans = "INSERT INTO transactions (agent_id, customer_name, waste_type_id, weight_kg, total_price, total_points, status) VALUES (?, ?, ?, ?, ?, ?, 'disetor')";
                    $stmt_trans = $connection->prepare($sql_trans);
                    $stmt_trans->bind_param('isidid', $agent_id, $customer_name, $waste_type_id, $weight_kg, $total_price, $total_points);
                    $stmt_trans->execute();
                    $transaction_id = $connection->insert_id;
                    $stmt_trans->close();

                    // Create notification for all admins
                    $message = "Transaksi baru #{$transaction_id} telah ditambahkan oleh agen {$_SESSION['name']}.";
                    $link = "../admin/laporan_transaksi.php?id={$transaction_id}";
                    $sql_notif = "INSERT INTO notifications (user_id, message, link) SELECT id, ?, ? FROM users WHERE role = 'admin'";
                    $stmt_notif = $connection->prepare($sql_notif);
                    $stmt_notif->bind_param('ss', $message, $link);
                    $stmt_notif->execute();
                    $stmt_notif->close();

                    $connection->commit();
                    $success_message = "Transaksi berhasil dicatat dengan ID #{$transaction_id}.";
                    // Clear form fields on success
                    $customer_name = $waste_type_id = $weight_kg = '';
                } else {
                    $error_message = "Jenis sampah tidak valid.";
                }
            } catch (Exception $e) {
                if (isset($connection) && $connection->in_transaction) {
                    $connection->rollback();
                }
                $error_message = "Gagal mencatat transaksi: " . $e->getMessage();
            }
        }
    }
}

$page_title = 'Setor Sampah';
include '../templates/header.php';
?>

<main class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="text-center"><?php echo htmlspecialchars($page_title); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($success_message) echo '<div class="alert alert-success">'.htmlspecialchars($success_message).'</div>'; ?>
                    <?php if($error_message) echo '<div class="alert alert-danger">'.htmlspecialchars($error_message).'</div>'; ?>
                    <?php if($fetch_error) echo '<div class="alert alert-warning">'.htmlspecialchars($fetch_error).'</div>'; ?>

                    <form method="POST" action="setor_sampah.php">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <div class="mb-3">
                            <label for="customer_name" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name" required value="<?php echo htmlspecialchars($customer_name); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="waste_type_id" class="form-label">Jenis Sampah</label>
                            <select class="form-select" id="waste_type_id" name="waste_type_id" required <?php if(empty($waste_types)) echo 'disabled'; ?>>
                                <option value="">-- Pilih Jenis Sampah --</option>
                                <?php foreach($waste_types as $type): ?>
                                <option value="<?php echo $type['id']; ?>" <?php if($type['id'] == $waste_type_id) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($type['name']); ?> (Rp <?php echo number_format($type['price_per_kg'], 0); ?>/kg)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="weight_kg" class="form-label">Berat (KG)</label>
                            <input type="number" step="0.1" min="0.1" class="form-control" id="weight_kg" name="weight_kg" required value="<?php echo htmlspecialchars($weight_kg); ?>">
                        </div>
                        <div class="d-grid">
                            <button type="submit" name="submit_transaction" class="btn btn-primary" <?php if(empty($waste_types)) echo 'disabled'; ?>>Simpan Transaksi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php 
include '../templates/footer.php'; 
if (isset($connection)) {
    $connection->close();
}
?>
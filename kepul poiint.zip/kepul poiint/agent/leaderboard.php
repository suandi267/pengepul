<?php
session_start();

// Security check: Ensure user is a logged-in agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$page_title = 'Papan Peringkat Agen';
include '../templates/header.php';

$leaderboard_data = [];
$fetch_error = '';

try {
    // Query to get agent rankings based on total revenue and total weight
    $sql = "SELECT 
                u.name as agent_name,
                COALESCE(SUM(t.total_price), 0) as total_revenue,
                COALESCE(SUM(t.weight_kg), 0) as total_weight
            FROM users u
            LEFT JOIN transactions t ON u.id = t.agent_id
            WHERE u.role = 'agent'
            GROUP BY u.id, u.name
            ORDER BY total_revenue DESC, total_weight DESC";

    $result = $connection->query($sql);
    $leaderboard_data = $result->fetch_all(MYSQLI_ASSOC);

} catch (mysqli_sql_exception $e) {
    $fetch_error = "Gagal memuat data papan peringkat: " . $e->getMessage();
}

?>

<main class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0"><?php echo htmlspecialchars($page_title); ?></h2>
        <i class="fas fa-trophy fa-2x text-warning"></i>
    </div>
    <p>Lihat peringkat agen berdasarkan total pendapatan dan berat sampah yang disetor.</p>

    <?php if ($fetch_error): ?>
        <div class="alert alert-danger"><?php echo $fetch_error; ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover text-center">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Peringkat</th>
                            <th scope="col" class="text-start">Nama Agen</th>
                            <th scope="col">Total Pendapatan</th>
                            <th scope="col">Total Berat Setoran (Kg)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($leaderboard_data)): ?>
                            <?php $rank = 1; ?>
                            <?php foreach ($leaderboard_data as $data): ?>
                                <tr>
                                    <td class="fw-bold">
                                        <?php 
                                        if ($rank == 1) echo '<i class="fas fa-medal text-warning"></i>';
                                        elseif ($rank == 2) echo '<i class="fas fa-medal text-secondary"></i>';
                                        elseif ($rank == 3) echo '<i class="fas fa-medal" style="color: #cd7f32;"></i>';
                                        else echo $rank;
                                        ?>
                                    </td>
                                    <td class="text-start"><?php echo htmlspecialchars($data['agent_name']); ?></td>
                                    <td>Rp <?php echo number_format($data['total_revenue'], 2, ',', '.'); ?></td>
                                    <td><?php echo number_format($data['total_weight'], 2, ',', '.'); ?> Kg</td>
                                </tr>
                                <?php $rank++; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Data tidak tersedia.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php
include '../templates/footer.php';
if (isset($connection)) {
    $connection->close();
}
?>
